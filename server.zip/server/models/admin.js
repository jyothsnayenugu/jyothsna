const mongoose = require('mongoose')
const Schema = mongoose.Schema

const AdminUser =  new Schema({
    email: String,
    password: String,
    name: String

});

const admin = mongoose.model("admin", AdminUser)
module.exports = admin;