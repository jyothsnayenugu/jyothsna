var mongoose = require('mongoose');
var Schema = mongoose.Schema;

const User =  new Schema({
    email: String,
    password: String

});

const users = mongoose.model("users", User)
module.exports = users;