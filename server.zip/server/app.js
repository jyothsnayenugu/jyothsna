const express = require('express')
const cors = require('cors')
const morgan = require('morgan')
const bodyparser = require('body-parser')
const mongoose = require('mongoose');
const path = require('path')
const nodemailer = require('nodemailer')

const PORT = process.env.PORT || 3000
const firebase = require('firebase')
mongoose.Promise=global.Promise;
const cdb = {
    user: 'user',
    password: 'password',
    host : 'localhost',
    port : '27017',
    db : 'wsp'
  };

mongoose.connect("mongodb://"+cdb.user+":"+cdb.password+"@"+cdb.host+":"+cdb.port+"/"+cdb.db,{useNewUrlParser:true}, function(err, res) {
  if(err) throw err;
  console.log('Successful connection to database');
}); 


// Initialize Firebase
var config = {
    apiKey: "AIzaSyCnf7hyaG_6YDVScYbU4lyCnt9-Yj12tU0",
    authDomain: "finalproject-e6142.firebaseapp.com",
    databaseURL: "https://finalproject-e6142.firebaseio.com",
    projectId: "finalproject-e6142",
    storageBucket: "finalproject-e6142.appspot.com",
    messagingSenderId: "805210732032"
  };
firebase.initializeApp(config);
const app = express()
app.use(bodyparser.urlencoded({extended:true}))
app.use(cors());
app.use(morgan('combined'));
app.use(bodyparser.json())
var Post = require('./models/Post');
var Au = require('./models/ArticleUser');
const admins = require('./models/admin');
const images = require('./models/image');

app.set('view engine','ejs')
app.set('views', './views')
app.use('/public',express.static(__dirname+"/public"));



//Signing up using firbase authentication.
app.post('/signup', async (req,res)=>{
    const email = req.body.email;
    const password = req.body.password;
    await firebase.auth().createUserWithEmailAndPassword(email,password)
    .then(user=>{
        res.send(user.user)
    })
    .catch(error=>{
        res.status(400).send({
            error
        })
    })

    var newUser = new Au({
        email: email,
        password: password
      })
      newUser.save(function (err,post) {
        if (err) return console.log("error occurred");
        return console.log("User registered")
      })
    })


app.post('/login', async (req,res)=>{
    const email = req.body.email;
    const password = req.body.password;
    await firebase.auth().signInWithEmailAndPassword(email,password)
    .then(user=>{
        res.send(user)
    })
    .catch(error=>{
        res.status(400).send({
            error
        })
    })
})


app.get('/logout', (req,res)=>{
    firebase.auth().signOut()
    .then(()=>{
        res.send()
    })
    .catch(error=>{
        res.status(400).send({
            error
        })
    })
})

app.get('/getPosts', (req, res) => {
         Post.find({},function (err,posts) {
                 if(err) return res.json(503);
                 return res.json(posts);
  }).sort({_id:-1})
})  

app.post('/addPost', (req, res) => {
    var data = req.body;
      var newPost = new Post({
        title: data.title,
        description:data.description
      });
      newPost.save(function (err,post) {
        if (err) return res.status(500).send(err);
        return res.json(post);
      })
})

app.post('/sendemail',(req,res)=>{
  const output =`
  <p>You have a new Reported Article</p>
  <h3>Sender Details:</h3>
  <ul>
     <li>Name: ${req.body.name}</li>
     <li>Email: ${req.body.email}</li>
     <li>Phone: ${req.body.phone}</li>
  </ul>
  <h3>Report Reason</h3>
  <p>${req.body.message}</p>`;

  let transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 587,
    Authentication: true,
    secure: false, // true for 465, false for other ports
    auth: {
      user: 'rangashashank2018@gmail.com', // generated ethereal user
      pass: 'application23' // generated ethereal password
    },
    tls:{
      rejectUnauthorized:false
    }
  });

  let mailOptions ={
    from: '"WordsSpeak Report" <rangashashank2018@gmail.com>', // sender address
    to: "rangashashank1@gmail.com", // list of receivers
    subject: "Article Report from WordsSpeak", // Subject line
    text: "Hello world?", // plain text body
    html: output // html body
  }

  // send mail with defined transport object
  transporter.sendMail(mailOptions, (error,info)=>{
    if(error){
      return console.log(error);
    }
  
  console.log("Message sent: %s", info.messageId);
  console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
});
res.status(200).send();
})

app.get('/admin',(req,res)=>{
  res.render('admin/signup')
})

app.post('/admin',(req,res)=>{
      const email = req.body.email;
      const password = req.body.password;
      const name = req.body.name;
    var newAdmin = new admins({
        email: email,
        password: password,
        name: name
      })
      newAdmin.save(function (err,post) {
        if (err) res.send("Invalid Email entered!!! Please Try again");
        res.render('admin/login')
      })
})

app.get('/admin/login',(req,res)=>{
  res.render('admin/login')
})

app.post('/admin/login',(req,res)=>{
  const email = req.body.email;
  const password = req.body.password;
  admins.find({email},function (err,user) {
    const result = user[0]
    if(err){
          res.send("Can't get your details")
      }else{
          if(result.email == email){
              if(result.password == password){
                  res.render('admin/home')
              }
              else{
                  res.send("please enter valid username and password")
              }
          }else{
              res.send("Admin not found!!! Please register first")
          }
      }
   })
})

app.get('/admin/home',(req,res)=>{
  res.render('admin/home')
})

app.get('/admin/users',(req,res)=>{
   Au.find({},function (err,users) {
    if(err) res.send("No User Available in database");
    return res.render('admin/userinfo',{users})
})
})

app.get('/admin/articles',(req,res)=>{
  Post.find({},function (err,posts) {
   if(err) return res.send("Retriving error in articles");
   return res.render('admin/articlesinfo',{posts})
})
})

app.post('/admin/deleteUser',(req,res)=>{
  const id = req.body._id;
  Au.remove({_id: id}, function(err){
    if(!err){
      res.render('admin/home')
    }else{
      res.send("Error while deleting user")
    }
  })
})

app.post('/admin/deleteArticle',(req,res)=>{
  const id = req.body._id;
  Post.findByIdAndRemove(id, function(err){
    if(!err){
      res.render('admin/home')
    }else{
      res.send("Error while deleting user")
    }
  })
})




app.get('/admin/profile',(req,res)=>{
  images.find({},function (err,image) {
    if(err) return res.send("Image not found");
    return res.render('admin/profile',{image})
 })
})

app.get('/admin/imageUpload',(req,res)=>{
  res.render('admin/imageUpload')
})

const multer = require('multer')

const MAX_FILESIZE = 1024 * 1024 * 1 // 1mb
const fileTypes= /jpeg|jpg|png|gif/;  // regular expression

const storageOptions = multer.diskStorage({
    destination:(req,file,callback)=>{
        callback(null,'./public/images');
    },
    filename:(req,file,callback)=>{
        callback(null,'image'+Date.now()+path.extname(file.originalname));
    }
});

const imageUpload = multer({
    storage: storageOptions,
    limits:{fileSize:MAX_FILESIZE},
    fileFilter:(req,file,callback)=>{
        const ext = fileTypes.test(path.extname(file.originalname).toLowerCase());
        const mimetype=fileTypes.test(file.mimetype);
        if(ext && mimetype){
            return callback(null,true)
        }else{
            return callback('Error: Images(jpeg,jpg,png,gif)only');
        }
    }
}).single('imageupload')

app.post('/admin/imageUpload',(req,res)=>{
  imageUpload(req,res,error=>{
      if(error){
          return res.send(error)
      }else if(!req.file){
          return res.send("please select a image file")
      }
     //upload the file to database
     const image = {filename:req.file.filename, size:req.file.size}
     const imageupload = new images({
       filename: image.filename,
       size : image.size
     })  
     imageupload.save(function(err,output){
       if(err) res.send("Image didn't upload to database")
       else res.redirect('/admin/profile')
     })
  })
})

app.listen(PORT,()=>{
    console.log(`Server running at port ${PORT}`)
})
